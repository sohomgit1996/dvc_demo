# for pytest to identify the test cases that functionname should start with test

def test_generic():
    a = 2
    b = 2
    assert a == b